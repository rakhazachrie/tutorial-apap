package apap.tutorial.emsidi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsidiApplicationTests {

	@Test
	void contextLoads() {
	}

}
