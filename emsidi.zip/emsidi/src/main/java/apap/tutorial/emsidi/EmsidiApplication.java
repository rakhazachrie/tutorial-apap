package apap.tutorial.emsidi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsidiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsidiApplication.class, args);
	}

}
